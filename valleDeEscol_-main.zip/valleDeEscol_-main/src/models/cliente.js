const  mongoose  = require("mongoose");

const clientSchema = mongoose.Schema({
    nombre_cliente:{
        type: String, 
        required: true
    },
    cantidad_pedido:{
        type: Number,
        required: true
    },
    valor_unidad:{
        type: Number,
        required: true
    },
    correo:{
        type: String,
        required: true
    },
    telefono:{
        type: Number,
        required: true
    }
});
module.exports = mongoose.model('cliente', clientSchema);